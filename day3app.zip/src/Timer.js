import React, { useEffect, useState } from "react";

const Timer = () => {
    const [count, setCount] = useState(0);

    useEffect(() => {
        let tr = setTimeout(() => {
            setCount((count) => count + 1);
        }, 1000);

        //cleanup 함수
        return (() => clearTimeout(tr));
    }, []);

    return (
        <h1>렌더링 횟수 : {count} 번</h1>
    );
}

export default Timer;