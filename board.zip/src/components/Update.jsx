import axios from "axios";
import React, { useCallback, useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import Button from "./Button";
import "./scss/Main.scss";
import "./scss/Input.scss";
import "./scss/Textarea.scss";
import "./scss/FileInput.scss";
import "./scss/Update.scss";

const Update = () => {
    const nav = useNavigate();

    const {state} = useLocation();      
    const {bn} = state;

    const id = sessionStorage.getItem("mid");
    const [data, setData] = useState({
        bnum: bn,
        btitle: "",
        bmid: id,
        bcontent: "",
    });

    //const [board, setBoard] = useState({});
    const [flist, setFlist] = useState([
        {
            bfnum: 0,
            bfbid: 0,
            bfsysname: "",
            bforiname: "Nothing",
            image: "",
        },
    ]);

    useEffect(() => {
        axios
            .get("/getBoard", { params: { bnum: bn } })
            .then((res) => {
                //console.log(res.data);
                setData(res.data);

                if (res.data.bfList.length > 0) {
                    let newFileList = [];
                    for (let i = 0; i < res.data.bfList.length; i++) {
                        const newFile = {
                            ...res.data.bfList[i],
                            image: "upload/" + res.data.bfList[i].bfsysname,
                        };
                        //console.log(newFile);
                        newFileList.push(newFile);
                    }
                    //console.log(newFileList);
                    setFlist(newFileList);
                }
            })
            .catch((err) => console.log(err));
    }, []);

    const [fileName, setFileName] = useState("선택된 파일이 없습니다.");

    //전송 데이터와 파일을 담을 멀티파트 폼 생성
    let formData = new FormData();
    const { btitle, bcontent } = data;

    //작성한 내용(글, 파일들) 전송 함수
    const onWrite = useCallback(
        (e) => {
            e.preventDefault();
            //console.log(data);
            //전송 시 파일 이외의 데이터를 폼데이터에 추가
            formData.append(
                "data",
                new Blob([JSON.stringify(data)], { type: "application/json" })
            );

            axios
                .post("/updateProc", formData, {
                    headers: { "Content-Type": "multipart/form-data" },
                })
                .then((res) => {
                    if (res.data === "ok") {
                        alert("수정 성공");
                        //sessionStorage.removeItem("pageNum");
                        nav("/board", {state: {bn: data.bnum}});
                    } else {
                        alert("수정 실패");
                        //formData = new FormData();
                    }
                })
                .catch((error) => console.log(error));
        },
        [data]
    );
    const onChange = useCallback(
        (e) => {
            const dataObj = {
                ...data,
                [e.target.name]: e.target.value,
            };
            //console.log(dataObj);
            setData(dataObj);
        },
        [data]
    );

    //파일 선택 시 폼데이터에 파일 목록 추가(다중파일)
    const onFileChange = useCallback(
        (e) => {
            const files = e.target.files;
            let fnames = "";

            for (let i = 0; i < files.length; i++) {
                formData.append("files", files[i]);
                fnames += files[i].name + " ";
            }
            if(fnames === ""){
                fnames = "선택된 파일이 없습니다.";
            }
            setFileName(fnames);
        },
        [formData]
    );

    const viewFlist = flist.map((v, i) => {
        //console.log(v);
        return (
            <div className="Down" key={i}>
                {v.image && <img src={v.image} alt="preview-img" />}
                {v.bforiname}
            </div>
        );
    });

    return (
        <div className="Main">
            <form className="Content" onSubmit={onWrite}>
                <h1>Board Update</h1>
                <input
                    className="Input"
                    name="btitle"
                    value={btitle}
                    placeholder="제목"
                    onChange={onChange}
                    autoFocus
                    required
                />
                <textarea
                    className="Textarea"
                    name="bcontent"
                    onChange={onChange}
                    placeholder="게시글을 작성하세요."
                    value={bcontent}
                ></textarea>
                <div className="Box">
                    <div className="FileTitle">File</div>
                    <div className="FileData">{viewFlist}</div>
                </div>
                <div className="FileInput">
                    <input id="upload1" type="file" multiple onChange={onFileChange} />
                    <label className="FileLabel" htmlFor="upload1">
                        파일선택
                    </label>
                    <span className="FileSpan">{fileName}</span>
                </div>
                <div className="Buttons">
                    <Button type="button" size="large" color="gray" wsize="s-10" outline 
                        onClick={() => nav('/board', {state: {bn: data.bnum}})}>
                        B
                    </Button>
                    <Button type="submit" size="large" wsize="s-30">
                        UPDATE
                    </Button>
                </div>
            </form>
        </div>
    );
};

export default Update;
