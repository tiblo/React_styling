import classname from "classname";
import React from "react";

const TableColumn = ({ children, span, wd }) => {
    return (
        <td className={classname("TableColumn", wd)} colSpan={span}>
            {children}
        </td>
    );
};

export default TableColumn;
