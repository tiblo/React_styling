import React from 'react';
import { Link } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHouse } from '@fortawesome/free-solid-svg-icons';
import './scss/Header.scss';

const Header = ({ lstate, onLogout }) => {
    const { logid, mlink } = lstate;
    const homeLink = logid === "" ? "/" : "/main";

    return (
        <div className='Header'>
            <div className='Content'>
                <Link to={homeLink}>
                    <FontAwesomeIcon icon={faHouse} size='2x' className='IconStyle' />
                </Link>
                <div className='Title'>ICIA Board</div>
                <div className='Menu'>
                    <div className='Item'>
                        <Link to={mlink}>
                            {logid !== "" ? `${logid}님` : 'Login'}
                        </Link>
                    </div>
                    <div className="Item">
                        {logid !== "" ? (
                        <span onClick={onLogout}>Logout</span>
                        ) : (
                        <Link to="/join">join</Link>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Header;