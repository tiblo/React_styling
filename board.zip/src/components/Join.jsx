import React, { useRef, useState } from "react";
import "./scss/Join.scss";
import "./scss/Input.scss";
import Button from "./Button";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { useForm } from "react-hook-form";

const Join = () => {
    const nav = useNavigate();

    let ck = false; //아이디 중복확인 여부 저장

    const { handleSubmit, register, watch, formState: {errors} } = useForm();

    //const mid = useRef();   

    const idCheck = () => {
        let mid = watch('mid'); //watch로 form의 입력값을 가져올 수 있다.
        
        if (mid === "") {
            alert("아이디를 입력하세요.");
            ck = false;
            return;
        }
        //서버로 중복확인 하기위해 전송하여 처리
        const sendId = { 'mid': mid };
        axios
            .post("/idCheck", sendId)
            .then((res) => {
                if(res.data.res === "ok"){
                    alert(res.data.msg);
                    ck = true;
                }
                else {
                    alert(res.data.msg);
                    ck = false;
                }
            })
            .catch((error) => {
                console.log(error)
                ck = false;
            });
        
        console.log(ck);
    };

    const onSubmit = (form) => {
        if(ck == false){
            alert('아이디 중복확인을 해주세요.');
            return;
        }
        
        axios
            .post("/joinProc", form)
            .then((res) => {
                if (res.data === "ok") {
                    alert("가입 성공");
                    nav("/login");
                }
            })
            .catch((error) => console.log(error));
    };

    return (
        <div className="Join">
            <form className="Content" onSubmit={handleSubmit(onSubmit)}>
                <h1>회원 가입</h1>
                <input className="Input" placeholder="아이디"
                    {...register('mid', { 
                        required: { value: true, message: '아이디는 필수 입력값입니다.' },
                    })} />
                {errors?.mid && <span className="Error">{errors?.mid?.message}</span>}
                <Button type="button" onClick={idCheck} outline>
                    중복확인
                </Button>
                <input className="Input" placeholder="비밀번호" type="password"
                    {...register('mpwd', {
                        required: { value: true, message: '비밀번호는 필수 입력값입니다.' },
                        minLength: { value: 8, message: '8자리 이상 입력해 주세요.'}
                    })} />
                {errors?.mpwd && <span className="Error">{errors?.mpwd?.message}</span>}
                <input className="Input" placeholder="이름"
                    {...register('mname', { 
                        required: { value: true, message: '이름은 필수 입력값입니다.' },
                    })} />
                {errors?.mname && <span className="Error">{errors?.mname?.message}</span>}
                <input className="Input" placeholder="연락처"
                    {...register('mphone', { 
                        required: { value: true, message: '연락처는 필수 입력값입니다.' },
                        pattern: {
                            value: /^01([0|1|6|7|8|9]?)-?([0-9]{3,4})-?([0-9]{4})$/,
                            message: '010-1234-5678 형식으로 입력해주세요'
                        }
                    })} />
                {errors?.mphone && <span className="Error">{errors?.mphone?.message}</span>}
                <Button type="submit" size="large">가입</Button>
            </form>
        </div>
    );
};

export default Join;
