import React from "react";

const TableRow = ({ children }) => {
    return <tr className="TableRow">{children}</tr>;
};

export default TableRow;
