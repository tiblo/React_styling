import classname from "classname";
import React from "react";
import "./scss/Button.scss";

const Button = (props) => {
    //구조분해 할당으로 크기, 색상, 가로크기, 외곽선 형식의 class 지정
    const { 
        children, 
        size = "medium", 
        color = "blue", 
        wsize = "basic", 
        outline, 
        ...rest } = props;

    return (
        <button
            className={classname("Button", size, color, wsize, { outline })}
            {...rest}
        >
            {children}
        </button>
    );
};

export default Button;
