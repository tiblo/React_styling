import axios from "axios";
import React, { useCallback, useState } from "react";
import { useNavigate } from "react-router-dom";
import Button from "./Button";
import "./scss/Login.scss";
import { useForm } from "react-hook-form";

const Login = ({ sucLogin }) => {
    const nav = useNavigate();

    const { handleSubmit, register, watch, formState: { errors } } = useForm();

    const sendLogin = (form) => {
        //console.log(form);

        axios
            .post("/loginProc", form)
            .then((res) => {
                //console.log(res.data);
                if (res.data.res === "ok") {
                    sucLogin(res.data.id);
                    //로그인 상태 유지(세션)
                    sessionStorage.setItem("mid", res.data.id);
                    nav("/main");
                } else {
                    alert(res.data.msg);
                }
            })
            .catch((err) => console.log(err));
    };

    return (
        <div className="Login">
            <form className="Content" onSubmit={handleSubmit(sendLogin)}>
                <h1>로그인</h1>
                <input className="Input" placeholder="아이디"
                    {...register('mid', {
                        required: { value: true, message: '아이디는 필수 입력값입니다.' },
                    })} />
                {errors?.mid && <span className="Error">{errors?.mid?.message}</span>}
                <input className="Input" placeholder="비밀번호" type="password"
                    {...register('mpwd', {
                        required: { value: true, message: '비밀번호는 필수 입력값입니다.' },
                        minLength: { value: 8, message: '8자리 이상 입력해 주세요.' }
                    })} />
                {errors?.mpwd && <span className="Error">{errors?.mpwd?.message}</span>}
                <Button type="submit" size="large">
                    로그인
                </Button>
            </form>
        </div>
    );
};

export default Login;
