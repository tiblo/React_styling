import React from "react";
import "./scss/Footer.scss";

const Footer = () => {
    return <div className="Footer">&copy;ICIA 2024</div>;
};

export default Footer;
