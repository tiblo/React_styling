import "./App.css";
import Header from "./Header";
import MyComp from "./MyComp";
import MyComponent from "./MyComponent";

function App() {
  const MyCar = { model: "올랜도", com: "쉐보레" };
  return (
    <>
      <Header logo="My App">Header입니다.</Header>
      <MyComponent title="App에서 보낸 값" writer="전우치" car={MyCar} />
      <MyComp name="아무개" fnum={5}>
        내용입니다
      </MyComp>
    </>
  );
}

export default App;
