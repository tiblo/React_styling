import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faHouse } from "@fortawesome/free-solid-svg-icons";

const Header = function (props) {
  const HeaderLogo = {
    fontSize: "20px",
    display: "inline",
  };
  const HeaderText = {
    display: "inline",
    marginLeft: "30px",
  };
  return (
    <div>
      <FontAwesomeIcon icon={faHouse} size="2x" />
      <div style={HeaderLogo}>{props.logo}</div>
      <div style={HeaderText}>{props.children}</div>
    </div>
  );
};

export default Header;
