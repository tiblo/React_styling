import React from "react";
import PropTypes from "prop-types";

//const MyComp = (props) => {
//  const { name, children } = props;
const MyComp = ({ name, fnum, children }) => {
  return (
    <div>
      {name}님이 만든 새 컴포넌트~
      <br />
      {children}!! {fnum}
    </div>
  );
};

MyComp.propTypes = {
  name: PropTypes.string,
  fnum: PropTypes.number.isRequired,
};

export default MyComp;
